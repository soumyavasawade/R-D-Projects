package com.soumya.bank;

public class CurrentAccount {

}
