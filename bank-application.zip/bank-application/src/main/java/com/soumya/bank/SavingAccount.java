package com.soumya.bank;

public class SavingAccount extends BankAccount{
	public  void withdraw(double amount) {
		System.out.println("Saving account withdraw method");
	}
/*public void isSalaryAccount() {
	System.out.println("Saving account");
	
}*/


}
