package com.soumya.bank;

public class Customer {
public static void main(String[] args)
{
	SavingAccount2 acc1=null;
acc1=new SavingAccount2();

	acc1.display();
	acc1.SavingAmount(5000);
acc1.withdraw(2000);



}
}
