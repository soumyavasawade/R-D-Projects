package com.soumya.bank;

public interface Insurance {

	void SavingAmount(double MinAmount);
	 
	void display();

	
	
	
}
