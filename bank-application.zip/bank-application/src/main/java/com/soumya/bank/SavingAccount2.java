package com.soumya.bank;

public class SavingAccount2 extends SavingAccount implements Insurance {

public void SavingAmount(double MinAmount) {
	MinAmount*=(1.1);
	System.out.println(+MinAmount);
}
public void display() {
	System.out.println("Invested in insurance");
}



}
